
package utilities;

public interface WasteProcessable {
    void process();
    String generateReport();
}
